package com.ipartek.controlador.admin.tipo;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ipartek.modelo.DB_Helper;
import com.ipartek.modelo.dto.Iva;
import com.ipartek.modelo.dto.Producto;
import com.ipartek.modelo.dto.Tipo;
import com.ipartek.modelo.dto.ViewProducto;


@WebServlet("/AdmTipoModificarFinal")
public class AdmTipoModificarFinal extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public AdmTipoModificarFinal() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//
		//hacer que si cambiamos algo, lo modifique en la BD
		//
		
		//1
		int id=0;
		if(request.getParameter("id")!=null)
		{
			id=Integer.parseInt(request.getParameter("id"));
		}

		String nombre="";
		if(request.getParameter("nombre")!=null)
		{
			nombre=request.getParameter("nombre");
		}
		
		
		Tipo ti= new Tipo(id, nombre);
		
	
		//3, 4 y 5
		DB_Helper db= new DB_Helper();
		Connection con= db.conectar();
	
		//operaciones
		//4.0 modificar
		boolean resultado= db.modificarTipo(con,ti );
		
		//4.1 obtener todos los tipos
		List<Tipo> listaTipos=db.obtenerTodosTipos(con);
		
		//4.2 obtener todos los ivas
		
	
		db.desconectar(con);
		
		
		//6 mochila
		request.setAttribute("lista",listaTipos );
		
		
		request.getRequestDispatcher("crud_tipos.jsp").forward(request, response);
	
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
