package com.ipartek.controlador.admin.tipo;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ipartek.modelo.DB_Helper;
import com.ipartek.modelo.dto.Iva;
import com.ipartek.modelo.dto.Tipo;
import com.ipartek.modelo.dto.ViewProducto;

/**
 * Servlet implementation class AdmTipoBorrar
 */
@WebServlet("/AdmTipoBorrar")
public class AdmTipoBorrar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdmTipoBorrar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int identificador=0;
		if(request.getParameter("id")!=null)
		{
			identificador=Integer.parseInt(request.getParameter("id"));
		}
		
		
		
		//3, 4 y 5
		DB_Helper db= new DB_Helper();
		Connection con= db.conectar();
		
		//operaciones
			//4.0 borrar el producto
			boolean resultado=db.borrarTipo(con, identificador);
		
			//4.1 obtener todos los tipos
			List<Tipo> listaTipos=db.obtenerTodosTipos(con);
			
			//4.2 obtener todos los ivas
			//List<Iva> listaIvas=db.obtenerTodosIvas(con);
			
			//4.3 obtener todos los productos de la vista
			List<ViewProducto> listaViewProducto=db.obtenerTodosViewProducto(con);
			
		db.desconectar(con);
		
		
		//6 mochila
		request.setAttribute("lista",listaTipos );
		//request.setAttribute("listaIvas",listaIvas );
		//request.setAttribute("listaViewProductos",listaViewProducto );
		
		//7 redirigir
		request.getRequestDispatcher("crud_tipos.jsp").forward(request, response);
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
